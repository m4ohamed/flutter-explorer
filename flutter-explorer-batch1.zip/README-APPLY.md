# حزمة تحسينات Flutter Explorer — الدفعة الأولى (مختبرة)

كل الملفات هنا **تنسخها فوق مشروعك بنفس المسارات** (المسارات نسبية لجذر `Desktop\new`).
اتختبرت كلها هنا: `tsc --noEmit` بنفس tsconfig بتاعك (strict, ES2020) = بدون أخطاء، و67 اختبار ناجح، وبناء esbuild سليم.

## 1) انسخ الملفات
| الملف | بيعمل إيه | استبدال/جديد |
|---|---|---|
| `src/utils/configWriter.ts` | كتابة آمنة للـ config (backup، atomic، ما بيمسحش ملف JSON تالف) | جديد |
| `src/utils/mcpSetup.ts` | يستخدم configWriter بدل الكتابة القديمة | استبدال |
| `src/mcp-arb-editor.ts` | يرفض الكتابة لو أي ARB تالف، atomic+backup، ICU parser حقيقي، unused keys صح | استبدال |
| `src/runtime/vmServiceBridge.ts` | hot reload/restart حقيقي عبر خدمات Flutter tool، استرجاع الـ isolate بعد restart، بدون success وهمي | استبدال |
| `src/utils/processRunner.ts` + `src/utils/analysisRunner.ts` | تشغيل أوامر بدون shell وبدون injection | جديد |
| `src/indexer/importResolver.ts` | resolver موحّد للـ imports والـ calls | جديد |
| `tests/` | 67 اختبار + `run-tests.js` | جديد |

## 2) أوامر لازمة
```
npm i -D ws @types/ws
```
وضيف في `package.json` → `scripts`:
```
"test": "node tests/run-tests.js",
"typecheck": "tsc --noEmit"
```
بعدها: `npm run typecheck && npm test && npm run compile`

## 3) تغييرات سلوك لازم تعرفها
- **ARB**: لو أي ملف `.arb` JSON تالف → أي كتابة بتتوقف وبترجّع الرسالة (قبل كده كان بيتمسح الملف). الملفات اللي لغتها مش في الطلب **بتتساب** (قبل كده كان بيتكتب فيها النص الإنجليزي). النسخ الاحتياطية في `~/.flutter-explorer/backups`.
- **VM bridge**: `flutter_hot_reload` / `flutter_hot_restart` بيشتغلوا بس لو التطبيق شغّال بـ `flutter run` أو `flutter attach`. `flutter_simulate_ui_action` بيرجّع success بس لو Flutter Driver أكّد التنفيذ.
- **mcpSetup**: `GEMINI.md` بقى بعلامات `<!-- flutter-explorer:rules:begin/end -->` وأي كلام بعده بيتحفظ. ملف config مش JSON صارم (تعليقات/فاصلة زيادة) بيتساب زي ما هو مع تحذير.

## 4) ⚠️ اللي لسه ما اتطبّقش (يحتاج وصول لملفاتك)
الوحدات `processRunner` و`analysisRunner` و`importResolver` موجودة لكن **لسه مش موصّلة** على `mcp-server.ts` و`mcp-code-analyzer.ts`:
- ثغرة `shell: true` في `flutter_run_analyze` **لسه موجودة** لحد ما نوصّل `runProjectAnalysis` مكانها.
- الـ imports لسه فاضية: لازم إصلاح `dartParser.ts` (الـ regex بيشتغل على نص الـ strings فيه ممسوحة) + `jsTsParser.ts` (إعادة كتابة على TypeScript compiler API) + دمج الـ imports في مسار الـ SDK داخل `indexManager.ts`.
- تعديلات أصغر: `skillsGenerator.ts` (مايكتبش في المشروع)، `extension.ts` (setting + debounce)، `fileWatcher.ts` (trigger في الـ web mode)، `packageResolver.ts` (path traversal)، `sidebar.js` (escape للـ quotes)، `package.json` (activationEvents).
افتحني من الكمبيوتر وقول «كمّل التوصيل» وهنفّذها بنفس الأسلوب (اختبار قبل التسليم).
